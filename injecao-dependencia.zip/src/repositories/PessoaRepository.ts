import { Repository } from './Repository';
import { singleton } from 'tsyringe';

export class PessoaRepository extends Repository<IPessoa>
  implements IPessoaRepository {}
